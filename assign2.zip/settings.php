<?php
    $host = "feenix-mariadb.swin.edu.au"; 
    $user = "s104848275"; 
    $password = "hardtoguess212005"; 
    $database = "s104848275_db"; 
?>